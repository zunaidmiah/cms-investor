<?php

Class EmailController extends BaseController{
    
    /*
    |--------------------------------------------------------------------------
    | Default Email Controller
    |--------------------------------------------------------------------------
    |
    |	Route::get('/', 'EmailController@index');
    |
    */
    
    public function __construct(){
        
        //contruct ccde Here.
        
        
    }
    
    public function index(){
        return View::make('admin.home');
    }
    
    public function publishNews(){
        
        if(Input::get('param') != null){
            $mediaNews  = new Medianews();
            $newsIds    = Input::get('param');
            $return = $mediaNews->publishSelected($newsIds);
            
            if($return){
                //code when news successfullt published
            }else{
                //code when successfully not published
            }
                
            return View::make('pages.web_scrapping_list')->with($data);
        }else{
            return Redirect::to('/');
        }
        
    }
    
    
    
    
}