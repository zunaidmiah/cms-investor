<?php

Class NewsController extends BaseController{
    
    /*
    |--------------------------------------------------------------------------
    | Default News Controller
    |--------------------------------------------------------------------------
    |
    |	Route::get('/', 'NewsController@index');
    |
    */
    
    public function __construct(){
        
        //contruct ccde Here. Eg; Checking the admin login
        
        
    }
    
    public function index(){
        return View::make('home');
    }
    
    public function news_centre_latest_media_news(){
        
        $mediaNews = new Medianews();
        $data['mediaNews'] = $mediaNews->getAll();
        $data['title'] = 'Latest Media News';
        
        return View::make('pages.news_centre_latest_media_news')->with($data);
        
    }
    
    
    
    
}