<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class Medianews extends Eloquent {

	use UserTrait, RemindableTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'media_news';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = array('password', 'remember_token');
        
        public function insert($data)
        {
            $this->date = $data['date'];
            $this->title = $data['title'];
            $this->heading = $data['heading'];
            $this->footer = $data['footer'];
            $this->content = $data['content'];
            $this->news_image = $data['news_image'];
            $this->status = $data['status'];
            $this->created_at = date("Y-m-d H:i:s", time());
            $this->updated_at = date("Y-m-d H:i:s", time());
            $this->save();
            return $this->id;
        }
        
        
        public function insertScraper($data)
        {
            $data['created_at'] = date("Y-m-d H:i:s", time());
            $data['updated_at'] = date("Y-m-d H:i:s", time());
            
            return $this::insertGetId($data);
        }
        
        public function getAll($number_of_record = null)
        {
            if(!empty($number_of_record)){
                return $this::paginate($number_of_record);
            }else{
                return $this::all();
            }
            
            //return $this::all()->paginate(2);
        }
        
        public function getMediaNews($id)
        {
            return $this::find($id);
        }
        
        public function getMediaNewsWithConditions($conditions)
        {
            return $this::where(array_keys($conditions)[0], array_values($conditions)[0])->pluck('id');
        }
        
        public function updateSingle($data)
        {
            $mediaNews = $this::find($data['id']);
            $mediaNews->date = $data['date'];
            $mediaNews->title = $data['title'];
            $mediaNews->heading = $data['heading'];
            $mediaNews->footer = $data['footer'];
            $mediaNews->content = $data['content'];
            $mediaNews->news_image = $data['news_image'];
            $mediaNews->status = $data['status'];
            $mediaNews->updated_at = time();
            
            $mediaNews->save();
            return $mediaNews->id;
        }
        
        public function updateSingleScraper($data)
        {
            $mediaNews = $this::find($data['id']);
            $mediaNews->date = $data['date'];
            $mediaNews->title = $data['title'];
            $mediaNews->link = $data['link'];
            $mediaNews->footer = $data['footer'];
            $mediaNews->content = $data['content'];
            $mediaNews->status = $data['status'];
            $mediaNews->updated_at = date("Y-m-d H:i:s", time());
            
            $mediaNews->save();
            return $mediaNews->id;
        }
        
        public function deleteMediaNews($id)
        {
            $mediaNews = $this::find($id);
            $mediaNews->delete();
            return $mediaNews->id;
        }
        
        public function deleteMultipleMediaNews($id)
        {
            if(is_string($id) && $id == 'all'){
                $this::truncate();
            }else{
                $this::destroy($id);
            }
            
            return true;
        }
        
        public function publishSelected($newsIds){
            
            if($newsIds){
                $mediaNews = $this::find($newsIds);
                $mediaNews->status = 1;
                $mediaNews->updated_at = time();

                $mediaNews->save();
                
                if($mediaNews->id){
                    return $mediaNews->id;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
            
            
        }
        
}
